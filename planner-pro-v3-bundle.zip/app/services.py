import os
import io
import csv
import json
import random
import requests
import itertools
from datetime import datetime
from openpyxl import Workbook
from .config import Config

from flask import current_app

class GenerationService:
    def __init__(self):
        # Load Resources on init
        # Note: In a real production app, we might want to lazy load or cache these better,
        # but for now, we'll log the init.
        pass

    def _get_logger(self):
        # specific helper to access current_app logger safely
        try:
            return current_app.logger
        except:
             # Fallback for scripts running outside context if ever needed
            import logging
            return logging.getLogger(__name__)

    def _load_customers(self):
        if hasattr(self, 'customers') and self.customers:
            return

        # 1. Try Google Sheet
        sheet_data = self._load_from_sheet()
        if sheet_data:
            self._get_logger().info("Loaded addresses from Google Sheet.")
            self.customers = sheet_data
            return

        # 2. Fallback to Local JSON
        try:
            with open(Config.CUSTOMERS_FILE, 'r', encoding='utf-8') as f:
                self.customers = json.load(f)
                self._get_logger().info("Loaded addresses from local JSON.")
        except Exception as e:
            self._get_logger().error(f"Error loading customers from JSON: {e}")
            self.customers = []

    def _load_template_headers(self):
        if hasattr(self, 'headers') and self.headers:
            return

        try:
            with open(Config.TEMPLATE_FILE, 'r', encoding='utf-8-sig') as f:
                reader = csv.reader(f, delimiter=';')
                self.headers = list(filter(None, next(reader)))
        except Exception as e:
            self._get_logger().error(f"Error loading CSV template: {e}")
            self.headers = []
            
    def _load_from_sheet(self):
        url = Config.ADDRESSES_SHEET_URL
        if not url:
            return None
        
        try:
            # Add timeout for production standards
            response = requests.get(url, timeout=10)
            response.raise_for_status()
            
            # Parse CSV
            # Data structure: Col A=Address, Col B=Country, Col C=City
            decoded_content = response.content.decode('utf-8')
            cr = csv.reader(decoded_content.splitlines(), delimiter=',')
            
            customers = []
            rows = list(cr)
            if not rows: return None
            
            for row in rows:
                if len(row) < 3: continue
                # Basic normalization
                addr = row[0].strip()
                country = row[1].strip()
                city = row[2].strip()
                
                # Simple heuristc to skip header
                if "direccion" in addr.lower() and "pais" in country.lower():
                    continue

                customers.append({
                    "address": addr,
                    "country": country,
                    "city": city,
                    "lat": "", # Sheet doesn't have it
                    "long": "",
                    "name": "Cliente Sheet", # Generic name
                    "id": f"S-{random.randint(1000,9999)}"
                })
            return customers

        except Exception as e:
            self._get_logger().error(f"Error fetching/parsing Google Sheet: {e}")
            return None

    def _get_localized_name(self, country_input):
        # Database of names
        LOCALE_DATA = {
            "LATAM": {
                "names": ["Juan", "Maria", "Carlos", "Ana", "Jose", "Luis", "Sofia", "Camila", "Pedro", "Diego"],
                "surnames": ["Gonzalez", "Rodriguez", "Perez", "Fernandez", "Lopez", "Diaz", "Martinez", "Silva", "Rojas", "Soto"]
            },
            "US": {
                "names": ["John", "Mary", "Michael", "Jennifer", "James", "Linda", "Robert", "Patricia", "David", "Elizabeth"],
                "surnames": ["Smith", "Johnson", "Williams", "Jones", "Brown", "Davis", "Miller", "Wilson", "Moore", "Taylor"]
            }
        }
        
        # Determine Region
        c = country_input.lower()
        if any(x in c for x in ["chile", "argentina", "colombia", "mexico", "peru", "bolivia", "uruguay", "ecuador", "venezuela", "paraguay"]):
            region = "LATAM"
        else:
            region = "US" # Default/Global
            
        data = LOCALE_DATA[region]
        return f"{random.choice(data['names'])} {random.choice(data['surnames'])}"

    def generate_excel(self, params):
        # Ensure resources loaded
        self._load_customers()
        self._load_template_headers()

        # Destructure params with safe defaults (validated by Frontend but be safe)
        count = params.get('cantidad_ordenes', 40)
        # Default Items to 1 if not present or 0
        items_per_order = int(params.get('items_por_orden') or 1)
        if items_per_order < 1: items_per_order = 1
        # Capacity
        cap_min = params.get('capacidad_min', 1)
        cap_max = params.get('capacidad_max', 10)
        
        if cap_min > cap_max:
             raise ValueError("Capacity Min cannot be greater than Capacity Max")

        # Capacity 2 (Optional)
        cap2_min = params.get('capacidad2_min')
        cap2_max = params.get('capacidad2_max')
        
        # Tags (Optional)
        tags = params.get('tags', []) # List of {header, values}

        # Windows
        win1_start = params.get('ventana_inicio', '09:00')
        win1_end = params.get('ventana_fin', '18:00')
        win2_start = params.get('ventana2_inicio')
        win2_end = params.get('ventana2_fin')
        
        
        # Optional
        ct_origin = params.get('ct_origen')
        
        if not ct_origin or str(ct_origin).strip() == "":
             raise ValueError("CT Origen is mandatory.")
        service_time = params.get('service_time')
        
        # Geo
        city_filter = params.get('ciudad', '')
        country_filter = params.get('pais', '')
        delivery_date = params.get('fecha_entrega', datetime.now().strftime('%Y-%m-%d'))

        # Date formatting
        try:
            date_obj = datetime.strptime(delivery_date, '%Y-%m-%d')
            formatted_date = date_obj.strftime('%d/%m/%Y')
        except:
            formatted_date = delivery_date

        # Filter customers
        # Filter customers logic
        # Rule: 
        # 1. Country MUST match (if provided)
        # 2. City MUST match (if provided AND not 'Other'/Empty)
        # 3. IF City is not provided/Other, fetch ALL from that Country.
        
        filtered_customers = []
        target_country = country_filter.lower().strip()
        target_city = city_filter.lower().strip()
        
        for c in self.customers:
            c_country = c.get('country', '').lower().strip()
            c_city = c.get('city', '').lower().strip()
            
            # Check Country
            if target_country and target_country not in c_country and "otro" not in target_country:
                continue
                
            # Check City (Only if specific city requested)
            # If target_city is "otro" or empty, we SKIP city filtering (accept all cities in country)
            if target_city and "otro" not in target_city:
                if target_city not in c_city:
                    continue
            
            filtered_customers.append(c)
        
        if not filtered_customers:
            filtered_customers = self.customers # Fallback

        if not filtered_customers:
             raise ValueError("No customer data available to generate orders.")

        # Shuffle once to ensure random order, then cycle
        random.shuffle(filtered_customers)
        customer_iterator = itertools.cycle(filtered_customers)

        wb = Workbook()
        ws = wb.active
        ws.title = "Ordenes Generadas"
        
        # Append Dynamic Headers
        for tag in tags:
            header_name = tag.get('header')
            if header_name and header_name not in self.headers:
                self.headers.append(header_name)
        
        ws.append(self.headers)

        global_item_counter = 1

        for i in range(count):
            # Use iterator instead of choice for unique cycling
            customer = next(customer_iterator)
            
            # Determine Name: If "Cliente Sheet" (placeholder) or empty, generate localized
            # If the sheet provided a real name (e.g., from JSON), keep it? 
            # User request: "create Contact Name in based on geo logic". 
            # So we override or fill. Let's override for maximum realism as requested.
            contact_name = self._get_localized_name(customer.get('country', country_filter))
            
            order_id = f"ORD-{str(i+1).zfill(6)}"
            
            # Pre-calculate capacity for the whole order (shared across rows)
             # Use uniform for float range. Format to 4 decimal places and replace dot with comma
            cap_val = random.uniform(cap_min, cap_max)
            cap_str = f"{cap_val:.4f}".replace('.', ',')

            # Cap 2 Logic
            cap2_str = ""
            if cap2_min is not None and cap2_max is not None:
                c2_val = random.uniform(cap2_min, cap2_max)
                cap2_str = f"{c2_val:.4f}".replace('.', ',')

            # Generate multiple rows if items_per_order > 1
            for j in range(items_per_order):
                # Row dict
                row = {h: "" for h in self.headers}

                # --- Mapping Logic ---
                
                # 1. Customer Info (Shared)
                row["N° DOCUMENTO"] = order_id
                row["LATITUD"] = str(customer.get('lat', '')).replace('.', ',')
                row["LONGITUD"] = str(customer.get('long', '')).replace('.', ',')
                row["DIRECCION"] = customer.get('address', '')
                
                
                # Contact (Shared)
                row["NOMBRE CONTACTO"] = contact_name
                row["IDENTIFICADOR CONTACTO"] = customer.get('id', '')
                row["TELEFONO"] = f"+569{random.randint(11111111,99999999)}"
                row["EMAIL CONTACTO"] = f"contacto{i}@example.com"

                # 2. Items (Distinct per row)
                row["NOMBRE ITEM"] = f"Item {global_item_counter}"
                row["CODIGO ITEM"] = f"SKU-{global_item_counter}" 
                row["CANTIDAD"] = "1" # 1 unit per line item
                row["COSTO ITEM"] = "1500" # Unit cost
                
                global_item_counter += 1

                # 3. Capacity (Shared)
                row["CAPACIDAD UNO"] = cap_str
                row["CAPACIDAD DOS"] = cap2_str
                
                # 4. Windows (Shared)
                row["FECHA MIN ENTREGA"] = formatted_date
                row["FECHA MAX ENTREGA"] = formatted_date
                row["MIN VENTANA HORARIA 1"] = win1_start
                row["MAX VENTANA HORARIA 1"] = win1_end
                
                if win2_start and win2_end:
                    row["MIN VENTANA HORARIA 2"] = win2_start
                    row["MAX VENTANA HORARIA 2"] = win2_end
                
                # 5. Optional Fields (Shared)
                if ct_origin:
                    row["CT ORIGEN"] = ct_origin
                else:
                    row["CT ORIGEN"] = "CD DEFAULT"
                    
                if service_time is not None:
                    row["SERVICE TIME"] = str(service_time)
                else:
                    row["SERVICE TIME"] = "5" # Default

                row["IMPORTANCIA"] = "1"
                
                # Dynamic Tags
                for tag in tags:
                    header = tag.get('header')
                    values = tag.get('values', [])
                    if header and values:
                        row[header] = random.choice(values)

                # Write Row
                # Check for explicit City/Country columns (if template has them) - Best effort
                if "CIUDAD" in self.headers:
                    row["CIUDAD"] = city_filter
                if "PAIS" in self.headers:
                    row["PAIS"] = country_filter

                ws.append([row.get(h, "") for h in self.headers])

        output = io.BytesIO()
        wb.save(output)
        output.seek(0)
        return output, f"ordenes_{count}.xlsx"

    def generate_vehicles_excel(self, vehicle_groups):
        """
        Generates a fleet Excel file based on groups.
        vehicle_groups: List of dicts:
            {
                "type": "Moto",
                "count": 5,
                "capacity1": 10,
                "capacity2": 5 (optional),
                "origin": "Bodega Central",
                "start_time": "09:00",
                "end_time": "18:00"
            }
        """
        wb = Workbook()
        ws = wb.active
        ws.title = "Flota Generada"
        
        # Headers - Strict Requirement
        headers = [
            "PLACA", "ORIGEN", "DESTINO", "CAPACIDAD UNO", "CAPACIDAD DOS", 
            "HORA INICIO JORNADA", "HORA FIN JORNADA", "INICIO HORA DESCANSO", 
            "FIN HORA DESCANSO", "COSTO POR SALIDA", "COSTO POR KILOMETRO", 
            "COSTO POR HORA", "COSTO FIJO", "MAXIMA CANTIDAD DE ENTREGAS POR RECORRIDO", 
            "MAXIMO TIEMPO DE MANEJO [HORAS]", "MAXIMA CANTIDAD DE RECORRIDOS", 
            "DISTANCIA MAXIMA POR RECORRIDO [KILOMETROS]", "VELOCIDAD VEHICULO", 
            "PERIODO DE RECARGA [HORAS]", "MAXIMO DE DINERO", "NO CONSIDERAR RETORNO AL CD"
        ]
        
        ws.append(headers)
        
        # Enforce Text Format for Header
        for cell in ws[1]:
            cell.number_format = '@'
        
        # Counters for Plate Generation
        prefix_map = {
            "Moto": "MOTO",
            "Auto": "AUTO",
            "Camion": "CAMI",
            "Bici": "BICI",
            "Otro": "OTRO"
        }
        
        counters = {k: 0 for k in prefix_map.values()}
        
        # Data Pools for "Realistic" Random filling of extra columns (based on user examples)
        speeds = ["Normal", "Baja", "Muy Alta"]
        
        for group in vehicle_groups:
            v_type = group.get('type', 'Otro')
            count = int(group.get('count', 0))
            cap1 = group.get('capacity1', '')
            cap2 = group.get('capacity2', '')
            origin = group.get('origin', '')
            start_time = group.get('start_time', '')
            end_time = group.get('end_time', '')
            
            # Prefix Logic
            prefix = prefix_map.get(v_type, "OTRO")
            if v_type not in prefix_map: 
                prefix = v_type[:4].upper()
                if prefix not in counters: counters[prefix] = 0

            for _ in range(count):
                counters[prefix] += 1
                sequence = counters[prefix]
                plate = f"{prefix}{str(sequence).zfill(3)}"
                
                # Default Values as per User Request (Step 673)
                # Most fields empty (""), specific ones with constants.
                
                row_data = {
                    "PLACA": plate,
                    "ORIGEN": origin,
                    "DESTINO": "",
                    "CAPACIDAD UNO": str(cap1).replace('.', ','),
                    "CAPACIDAD DOS": str(cap2).replace('.', ',') if cap2 else "",
                    "HORA INICIO JORNADA": start_time,
                    "HORA FIN JORNADA": end_time,
                    "INICIO HORA DESCANSO": "",
                    "FIN HORA DESCANSO": "",
                    "COSTO POR SALIDA": "",
                    "COSTO POR KILOMETRO": "",
                    "COSTO POR HORA": "",
                    "COSTO FIJO": "",
                    "MAXIMA CANTIDAD DE ENTREGAS POR RECORRIDO": "",
                    "MAXIMO TIEMPO DE MANEJO [HORAS]": "",
                    "MAXIMA CANTIDAD DE RECORRIDOS": "",
                    "DISTANCIA MAXIMA POR RECORRIDO [KILOMETROS]": "",
                    "VELOCIDAD VEHICULO": "Normal",
                    "PERIODO DE RECARGA [HORAS]": "0",
                    "MAXIMO DE DINERO": "",
                    "NO CONSIDERAR RETORNO AL CD": "1"
                }

                # Construct list in order
                row_values = [str(row_data.get(h, "")) for h in headers]
                
                ws.append(row_values)
                
                # Enforce Text Format
                for cell in ws[ws.max_row]:
                    cell.number_format = '@'

        output = io.BytesIO()
        wb.save(output)
        output.seek(0)
        return output, "flota_vehiculos.xlsx"
